// Pohua · RFQ Quoter — Service Worker (PWA)
//
// ============================================================================
// POR QUÉ ESTE FICHERO SE REESCRIBIÓ
// ============================================================================
// La versión anterior servía TODO cache-first, incluido el HTML. Eso rompía la
// aplicación después de cada despliegue, y de una forma difícil de diagnosticar:
//
//   - Quien ya había entrado alguna vez recibía el index.html viejo desde la
//     caché, para siempre. El index.html es el fichero que NOMBRA a todos los
//     demás, así que un index viejo pedía scripts viejos y se saltaba los
//     nuevos: la mitad de la aplicación no llegaba a cargarse y la pantalla se
//     quedaba en el fondo estrellado, sin contenido.
//
//   - `cache.addAll()` es todo o nada: si UN solo fichero de la lista devolvía
//     404 (por ejemplo, uno recién añadido que aún no estaba desplegado), la
//     instalación entera fallaba, el service worker nuevo no llegaba a
//     activarse y el viejo seguía sirviendo ficheros antiguos indefinidamente.
//
// ============================================================================
// LA ESTRATEGIA AHORA
// ============================================================================
//   /api/            la red, siempre. Llevan token y datos vivos.
//   navegación       la red primero; la caché sólo si no hay conexión.
//   .js y .css       la red primero. Junto con el HTML forman un conjunto que
//                    tiene que ser coherente: servir un script viejo con un
//                    HTML nuevo es justo el fallo que se está arreglando.
//   imágenes, fuentes, manifest
//                    la caché primero. Cambian poco y, si una queda vieja, no
//                    rompe nada: se ve un logo de hace un despliegue.
//
// Se pierde algo de velocidad en la primera carga a cambio de que la aplicación
// no pueda quedarse coherentemente rota. Sin conexión sigue abriendo, que es
// para lo que está el service worker.
// ============================================================================

const VERSION = 'v78';
const CACHE = `cgr-quoter-${VERSION}`;

// Lo mínimo para que la aplicación abra sin conexión. No hace falta listarlo
// todo: lo demás se guarda solo según se va usando.
const PRECARGA = [
    '/',
    '/css/style.css',
    '/js/i18n.js',
    '/js/pages/home.js',
    '/js/hero.js',
    '/js/app.js',
    '/js/api.js',
    '/manifest.json',
    '/assets/icon-192.png',
    '/assets/favicon-32.png',
];

// --------------------------------------------------------------------------
// Instalación
// --------------------------------------------------------------------------
self.addEventListener('install', (evento) => {
    evento.waitUntil((async () => {
        const cache = await caches.open(CACHE);

        // Uno a uno y tolerando fallos, NO con addAll: así un fichero que
        // todavía no esté desplegado no impide que el service worker nuevo se
        // instale. Un recurso que falte aquí se pedirá a la red cuando toque.
        await Promise.all(PRECARGA.map(async (ruta) => {
            try {
                await cache.add(new Request(ruta, { cache: 'reload' }));
            } catch (err) {
                console.warn('[sw] no se pudo precargar', ruta, err);
            }
        }));

        await self.skipWaiting();
    })());
});

// --------------------------------------------------------------------------
// Activación
// --------------------------------------------------------------------------
self.addEventListener('activate', (evento) => {
    evento.waitUntil((async () => {
        // Fuera cualquier caché que no sea la de esta versión. Esto es lo que
        // repara de golpe a quien tuviera guardada la mezcla vieja.
        const nombres = await caches.keys();
        await Promise.all(nombres.filter(n => n !== CACHE).map(n => caches.delete(n)));
        await self.clients.claim();
    })());
});

// --------------------------------------------------------------------------
// Peticiones
// --------------------------------------------------------------------------

/** Guarda en caché sólo lo que tiene sentido guardar. */
async function guardar(peticion, respuesta) {
    // `basic` = mismo origen. Las opacas (otro origen, sin CORS) no se pueden
    // inspeccionar: guardarlas es guardar posiblemente un error.
    if (!respuesta || !respuesta.ok || respuesta.type !== 'basic') return;
    const cache = await caches.open(CACHE);
    await cache.put(peticion, respuesta.clone());
}

/** La red primero; la caché es el plan B cuando no hay conexión. */
async function redPrimero(peticion, alternativa) {
    try {
        const respuesta = await fetch(peticion);
        guardar(peticion, respuesta);   // sin await: no hace esperar a la página
        return respuesta;
    } catch (err) {
        const guardada = await caches.match(peticion);
        if (guardada) return guardada;
        if (alternativa) {
            const shell = await caches.match(alternativa);
            if (shell) return shell;
        }
        throw err;
    }
}

/** La caché primero, y se actualiza por detrás para la próxima vez. */
async function cachePrimero(peticion) {
    const guardada = await caches.match(peticion);
    if (guardada) {
        // Refresco en segundo plano: la próxima carga ya tendrá la nueva.
        fetch(peticion).then(r => guardar(peticion, r)).catch(() => {});
        return guardada;
    }
    const respuesta = await fetch(peticion);
    guardar(peticion, respuesta);
    return respuesta;
}

self.addEventListener('fetch', (evento) => {
    const peticion = evento.request;

    // Sólo GET: un POST no se puede guardar en caché y cache.put lanzaría.
    if (peticion.method !== 'GET') return;

    const url = new URL(peticion.url);

    // Otro origen: que lo resuelva el navegador a su manera.
    if (url.origin !== self.location.origin) return;

    // La API nunca se cachea: lleva token y datos que cambian.
    if (url.pathname.startsWith('/api/')) return;

    // Navegación: SIEMPRE la red primero. El HTML nombra al resto de ficheros,
    // así que servirlo viejo desincroniza la aplicación entera.
    if (peticion.mode === 'navigate') {
        evento.respondWith(redPrimero(peticion, '/'));
        return;
    }

    // Código: la red primero, por la misma razón: HTML y scripts tienen que
    // venir del mismo despliegue.
    if (/\.(?:js|css)$/.test(url.pathname)) {
        evento.respondWith(redPrimero(peticion));
        return;
    }

    // Lo demás (imágenes, fuentes, manifest): la caché primero.
    evento.respondWith(cachePrimero(peticion));
});
